package User_defined_Exception;

public class CheckNegative
{
	public int sqr(int n)throws MyCustException
	{
		if(n<0)
		{
			throw new MyCustException("Zero or negative not allowed");
		}
		return n*n;
	}
}