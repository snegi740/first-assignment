package FirstCosignment;

public class TryingTryCatch {
    public static void main(String args[])
    {
        int arr[]=new int[4];
        TryingTryCatch e1= null;
        System.out.println("Array created");
        try
        {
            arr[3]=10;
            e1.toString();
           System.out.println("Array assigned");
        }
        catch(ArrayIndexOutOfBoundsException ae) 
        {
            System.out.println(ae);
        }
        catch(NullPointerException ne)
        {
            System.out.println(ne);
        }
        
    }

}
