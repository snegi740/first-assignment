package FirstCosignment;
import java.util.Scanner;

public class FakeStrcmpi {

	public static void main(String[] args) {
		
		@SuppressWarnings("resource")
		Scanner s=new Scanner(System.in);
		
		String string1= s.nextLine();
		String string2=s.nextLine();
		
		PrintingResult res=new PrintingResult();
		res.printingResult(string1, string2);
		

	}

}
