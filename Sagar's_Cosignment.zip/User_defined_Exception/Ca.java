package User_defined_Exception;

public class Ca
{
	public static void main(String args[])
	{
		CheckNegative a = new CheckNegative();
		int res = 0;
		try
		{
			res = a.sqr(-13);
			
			System.out.println(res);
		}
		catch(MyCustException j)
		{
			System.out.println(j);
		}
		System.out.println("Program Executed. Result Achieved");
	}
}
