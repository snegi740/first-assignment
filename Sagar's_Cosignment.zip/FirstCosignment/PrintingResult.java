package FirstCosignment;

public class PrintingResult {

	int a,b;
	int modified;
	int len1, len2;
	
	
	
	void printingResult(String input1, String input2) {
		
		len1=input1.length();
		len2=input1.length();
		
		
		if(len1!=len2) {
			System.out.println("string is not of same length");
		}
		
		if(len1>len2) {
			
			// swapping the small array to array1
			String temp=input1;
			input1=input2;
			input2=temp;
			
		}
			
		for(int i=0; i<len1;i++) {
			
			int asci1=input1.charAt(i);
			int asci2=input2.charAt(i);

			//capitals to small
			if(65<=asci1 && asci1<=90 && 65<=asci2 && asci2<=90) {
				
				a=asci1+32;
				b=asci2+32;
				
			//taking small as it is	
			}else {
				a=asci1;
				b=asci2;	
			}
			
			//getting difference 
				modified=a-b;
				
				if(modified==0) {
					if(i==len1-1) {
						System.out.println("0");

					}
					
				
				}
				else if(modified<0) {
					System.out.println("-1");
					break;
				
			}
				else  {
					System.out.println("1");
					break;
			
		}

		}
	}
}
