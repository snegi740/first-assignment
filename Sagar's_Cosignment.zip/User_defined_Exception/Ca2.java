package User_defined_Exception;

public class Ca2
{
	static void disp()throws MyCustException
	{
		CheckNegative a = new CheckNegative();
		int res = 0;
		res = a.sqr(-13);
		
		System.out.println(res);
	}
	public static void main(String args[])
	{
		try
		{
			disp();
		}
		catch(MyCustException j)
		{
			System.out.println(j);
			
			System.out.println("Error while executing disp()");
		}
		//have to have to be printed
		finally {
		System.out.println("Frint this!! You have to.");
		}
	}
}