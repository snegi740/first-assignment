package User_defined_Exception;

@SuppressWarnings("serial")
public class MyCustException extends Exception
{
	public MyCustException(String mess)
	{
		super(mess);
		System.out.println("This is my custom Exception. Accept it!!");
	}
}
